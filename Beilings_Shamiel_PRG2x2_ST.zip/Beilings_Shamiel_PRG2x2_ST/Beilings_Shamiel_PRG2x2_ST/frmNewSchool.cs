﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Beilings_Shamiel_PRG2x2_ST
{
    public partial class frmNewSchool : Form
    {
        public frmNewSchool()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
                {
                if (txtSchoolName.TextLength < 8)
                {
                    MessageBox.Show("School Name has to be more than 8 character");
                }
                else if (txtLocation.TextLength < 8)
                {
                    MessageBox.Show("Location has to be more than 8 character");
                }
                else
                {
                    string SchoolName = txtSchoolName.Text.Substring(0,3);
                    string Location = txtLocation.Text.Substring(0,2);
                    txtUname.Text = SchoolName + "" + Location;
                    string Uname = txtUname.Text.ToUpper();
                    txtUname.Text = Uname;
                    

                    string filename = @"C:\Users\shami\Documents\C#\Username.txt";
                    using ( StreamWriter writer = new StreamWriter(filename) ) 
                    {
                        writer.WriteLine(txtSchoolName.Text+"#"+Uname);
                    }

                    SqlConnection conn = new SqlConnection();
                    conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = SA_SCHOOLS; Integrated Security = SSPI";
                    conn.Open();

                    SqlCommand cmdInsert = new SqlCommand("Insert into SCH_DET(SchoolUserName , SchoolName, SchoolLocation) VALUES ('" + Uname + "', '" + txtSchoolName.Text + "', '" + txtLocation.Text +"')", conn);
                    int insertedRows = cmdInsert.ExecuteNonQuery();
                    
                    conn.Close();

                    MessageBox.Show(@"Username Generated and saved to Database and Locally to C:\Users\shami\Documents\C#\Username.txt" + "\n\n Username is: " + Uname + "\n\nPlease remember your Username\nIt is needed for Logging In");
                   
                    Form1 currmenu= new Form1();
                    this.Hide();
                    currmenu.Show();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Form1 currmenu = new Form1();
            this.Hide();
            currmenu.Show();
        }
    }
}

﻿namespace Beilings_Shamiel_PRG2x2_ST
{
    partial class frmSAEduHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvSchoolInfo = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.btnback = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSchoolInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvSchoolInfo
            // 
            this.dgvSchoolInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSchoolInfo.Location = new System.Drawing.Point(60, 32);
            this.dgvSchoolInfo.Name = "dgvSchoolInfo";
            this.dgvSchoolInfo.Size = new System.Drawing.Size(749, 369);
            this.dgvSchoolInfo.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(165, 428);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(495, 47);
            this.button1.TabIndex = 1;
            this.button1.Text = "Load School Information";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnback
            // 
            this.btnback.Location = new System.Drawing.Point(627, 496);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(270, 39);
            this.btnback.TabIndex = 2;
            this.btnback.Text = "GoBack";
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // frmSAEduHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 561);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dgvSchoolInfo);
            this.Name = "frmSAEduHome";
            this.Text = "SA Education Home";
            ((System.ComponentModel.ISupportInitialize)(this.dgvSchoolInfo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvSchoolInfo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnback;
    }
}
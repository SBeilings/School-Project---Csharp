﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Beilings_Shamiel_PRG2x2_ST
{
    public partial class frmAdminReg : Form
    {
        public frmAdminReg()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string uname = txtUname.Text;
                string pass = txtPass.Text;
                string returned_uname = "Not Found";
                if (uname.Length == 5 )
                {
                    SqlConnection conn = new SqlConnection();
                    conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = SA_SCHOOLS; Integrated Security = SSPI";
                    conn.Open();
                    SqlCommand cmdSelect = new SqlCommand("SELECT SchoolUserName From SCH_DET WHERE SchoolUserName = '" + uname + "'", conn);
                    SqlDataReader dr = cmdSelect.ExecuteReader();
                    
                    while (dr.Read())
                    {
                        returned_uname = dr.GetString(0);
                    }

                    dr.Close();
                    conn.Close();
                    
                    if (returned_uname == uname)
                    {
                        if (pass == "123") 
                        {
                            MessageBox.Show("Logged in Successfully");

                            frmAdminHome currmenu = new frmAdminHome();
                            this.Hide();
                            currmenu.Show();

                        }
                        else 
                        {
                            MessageBox.Show("Password Incorrect");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Username Does not Exist\n\n Please Register School First!");
                    }
                }
                else
                {
                    MessageBox.Show("Username is always 5 characters long!");
                }


            }
            catch (Exception ex)
            {

                
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Form1 currmenu = new Form1();
            this.Hide();
            currmenu.Show();
        }


    }
}

﻿namespace Beilings_Shamiel_PRG2x2_ST
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEduDep = new System.Windows.Forms.Button();
            this.btnSchoolAdmin = new System.Windows.Forms.Button();
            this.btnReg = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnEduDep
            // 
            this.btnEduDep.Location = new System.Drawing.Point(324, 25);
            this.btnEduDep.Name = "btnEduDep";
            this.btnEduDep.Size = new System.Drawing.Size(250, 145);
            this.btnEduDep.TabIndex = 0;
            this.btnEduDep.Text = "SA education department";
            this.btnEduDep.UseVisualStyleBackColor = true;
            this.btnEduDep.Click += new System.EventHandler(this.btnEduDep_Click);
            // 
            // btnSchoolAdmin
            // 
            this.btnSchoolAdmin.Location = new System.Drawing.Point(324, 222);
            this.btnSchoolAdmin.Name = "btnSchoolAdmin";
            this.btnSchoolAdmin.Size = new System.Drawing.Size(250, 145);
            this.btnSchoolAdmin.TabIndex = 1;
            this.btnSchoolAdmin.Text = "School Admin";
            this.btnSchoolAdmin.UseVisualStyleBackColor = true;
            this.btnSchoolAdmin.Click += new System.EventHandler(this.btnSchoolAdmin_Click);
            // 
            // btnReg
            // 
            this.btnReg.Location = new System.Drawing.Point(265, 471);
            this.btnReg.Name = "btnReg";
            this.btnReg.Size = new System.Drawing.Size(369, 88);
            this.btnReg.TabIndex = 2;
            this.btnReg.Text = "Click Here to Register New School";
            this.btnReg.UseVisualStyleBackColor = true;
            this.btnReg.Click += new System.EventHandler(this.btnReg_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(944, 571);
            this.Controls.Add(this.btnReg);
            this.Controls.Add(this.btnSchoolAdmin);
            this.Controls.Add(this.btnEduDep);
            this.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Log in / Register";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEduDep;
        private System.Windows.Forms.Button btnSchoolAdmin;
        private System.Windows.Forms.Button btnReg;
    }
}


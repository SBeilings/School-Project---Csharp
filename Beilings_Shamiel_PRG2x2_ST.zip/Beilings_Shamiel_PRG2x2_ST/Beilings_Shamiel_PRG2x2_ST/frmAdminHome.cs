﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Beilings_Shamiel_PRG2x2_ST
{
    public partial class frmAdminHome : Form
    {
        public frmAdminHome()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string sname = txtSName.Text;
            string grade =  txtGrade.Text;
            int mark = int.Parse(txtMark.Text);
            string category = "Reward Category Not Found";
            try
            {

                if (59 < mark && mark < 79)
                {
                    category = "Certificate";
                }
                else if (79 < mark && mark < 89)
                {
                    category = "Certificate and Medal";
                }
                else if (89 < mark && mark <= 100)
                {
                    category = "Certificate, Medal and Trophy";
                }

                lblCategory.Text = category;

                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = SA_SCHOOLS; Integrated Security = SSPI";
                conn.Open();

                SqlCommand cmdInsert = new SqlCommand("Insert into Students(StudentName , StudentSurname, StudentGrade, StudentMark, StudentCategory) " +
                    "VALUES ('" + name + "', '" + sname + "', '" + grade + "', '" + mark + "', '" + (string)category + "')", conn);
                int insertedRows = cmdInsert.ExecuteNonQuery();

                conn.Close();

                MessageBox.Show("Student Details Updated Successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("You entered something funky into the textboxes, Please fix");
            }
        }

        private void txtMark_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnback_Click(object sender, EventArgs e)
        {
            frmAdminReg currmenu = new frmAdminReg();
            this.Hide();
            currmenu.Show();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            var slcquery = "SELECT * FROM Students";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = SA_SCHOOLS; Integrated Security = SSPI";
            conn.Open();
            var dataAdapter = new SqlDataAdapter(slcquery, conn);            
            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            conn.Close(); 
            dgvStudentInfo.ReadOnly = true;
            dgvStudentInfo.DataSource = ds.Tables[0];
        }

        private void btnDelegate_Click(object sender, EventArgs e)
        {
            int mark = int.Parse(txtMark.Text);
            string category = "Reward Category Not Found";
            try
            {
                if (59 < mark && mark < 79)
                {
                    category = "Certificate";
                }
                else if (79 < mark && mark < 89)
                {
                    category = "Certificate and Medal";
                }
                else if (89 < mark && mark <= 100)
                {
                    category = "Certificate, Medal and Trophy";
                }

                lblCategory.Text = category;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}

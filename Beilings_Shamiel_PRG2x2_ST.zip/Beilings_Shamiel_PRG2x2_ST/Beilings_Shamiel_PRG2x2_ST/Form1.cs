﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Beilings_Shamiel_PRG2x2_ST
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            frmNewSchool currmenu = new frmNewSchool();
            this.Hide();
            currmenu.Show();
        }

        private void btnSchoolAdmin_Click(object sender, EventArgs e)
        {
            frmAdminReg currmenu = new frmAdminReg();
            this.Hide();
            currmenu.Show();
        }

        private void btnEduDep_Click(object sender, EventArgs e)
        {
            frmSAEduHome currmenu = new frmSAEduHome();
            this.Hide();
            currmenu.Show();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Beilings_Shamiel_PRG2x2_ST
{
    public partial class frmSAEduHome : Form
    {
        public frmSAEduHome()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var slcquery = "SELECT * FROM SCH_DET";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = SA_SCHOOLS; Integrated Security = SSPI";
            conn.Open();
            var dataAdapter = new SqlDataAdapter(slcquery, conn);
            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            conn.Close();
            dgvSchoolInfo.ReadOnly = true;
            dgvSchoolInfo.DataSource = ds.Tables[0];
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Form1 currmenu = new Form1();
            this.Hide();
            currmenu.Show();
        }
    }
}

USE [SA_SCHOOLS]
GO

/****** Object:  Table [dbo].[Students]    Script Date: 3/26/2022 11:31:09 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Students](
	[StudentName] [varchar](50) NULL,
	[StudentSurname] [varchar](50) NULL,
	[StudentGrade] [varchar](50) NULL,
	[StudentMark] [varchar](50) NULL,
	[StudentCategory] [varchar](50) NULL
) ON [PRIMARY]
GO

